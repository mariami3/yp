package com.example.demo.service;

import com.example.demo.entity.StudentEntity;
import com.example.demo.model.StudentModel;
import com.example.demo.repository.InMemoryStudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class InMemoryStudentServiceImpl implements StudentService {

    @Autowired
    private InMemoryStudentRepository repository;

    private StudentModel toModel(StudentEntity e){
        if (e==null) return null;
        return new StudentModel(e.getId(), e.getFirstName(), e.getLastName(), e.getGroupName(), e.getBirthDate());
    }

    private StudentEntity toEntity(StudentModel m){
        if (m==null) return null;
        StudentEntity e = new StudentEntity();
        e.setId(m.getId());
        e.setFirstName(m.getFirstName());
        e.setLastName(m.getLastName());
        e.setGroupName(m.getGroupName());
        e.setBirthDate(m.getBirthDate());
        return e;
    }

    @Override
    public List<StudentModel> findAllStudent() {
        return repository.findAll(false).stream().map(this::toModel).collect(Collectors.toList());
    }

    @Override
    public StudentModel findStudentById(int id) {
        return toModel(repository.findById(id));
    }

    @Override
    public StudentModel addStudent(StudentModel student) {
        StudentEntity e = toEntity(student);
        e.setId(0);
        return toModel(repository.save(e));
    }

    @Override
    public StudentModel updateStudent(StudentModel student) {
        StudentEntity e = toEntity(student);
        repository.save(e);
        return toModel(e);
    }

    @Override
    public void deleteStudentLogical(int id) {
        repository.deleteByIdLogical(id);
    }

    @Override
    public void deleteStudentPhysical(int id) {
        repository.deleteByIdPhysical(id);
    }

    @Override
    public void deleteMultipleLogical(java.util.List<Integer> ids) {
        repository.deleteMultipleLogical(ids);
    }

    @Override
    public void deleteMultiplePhysical(java.util.List<Integer> ids) {
        repository.deleteMultiplePhysical(ids);
    }

    @Override
    public List<StudentModel> search(String term) {
        return repository.searchBy(term).stream().map(this::toModel).collect(Collectors.toList());
    }

    @Override
    public List<StudentModel> filter(String group, LocalDate from, LocalDate to) {
        return repository.filter(group, from, to).stream().map(this::toModel).collect(Collectors.toList());
    }

    @Override
    public List<StudentModel> page(int pageIndex, int pageSize) {
        return repository.findPage(pageIndex, pageSize).stream().map(this::toModel).collect(Collectors.toList());
    }

    @Override
    public int getTotalCount() {
        return repository.findAll(false).size();
    }
}
