package com.example.demo.service;

import com.example.demo.model.StudentModel;

import java.time.LocalDate;
import java.util.List;

public interface StudentService  {
    List<StudentModel> findAllStudent();
    StudentModel findStudentById(int id);
    StudentModel addStudent(StudentModel student);
    StudentModel updateStudent(StudentModel student);
    void deleteStudentLogical(int id);
    void deleteStudentPhysical(int id);
    void deleteMultipleLogical(java.util.List<Integer> ids);
    void deleteMultiplePhysical(java.util.List<Integer> ids);

    List<StudentModel> search(String term);
    List<StudentModel> filter(String group, LocalDate from, LocalDate to);
    List<StudentModel> page(int pageIndex, int pageSize);
    int getTotalCount();
}
