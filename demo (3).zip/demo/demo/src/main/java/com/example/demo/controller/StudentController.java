package com.example.demo.controller;

import com.example.demo.model.StudentModel;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping({"", "/"})
    public String list(
            Model model,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String group,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        size = Math.max(size, 10);

        List<StudentModel> list;
        if (search != null && !search.isBlank()) {
            list = studentService.search(search);
        } else if ((group != null && !group.isBlank()) || from != null || to != null) {
            list = studentService.filter(group, from, to);
        } else {
            list = studentService.page(page, size);
        }

        int totalPages = (int) Math.ceil((double) studentService.getTotalCount() / size);

        model.addAttribute("students", list);
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("search", search);
        model.addAttribute("group", group);
        model.addAttribute("from", from);
        model.addAttribute("to", to);
        model.addAttribute("totalPages", totalPages);
        return "studentList";
    }

    @PostMapping("/add")
    public String addStudent(@ModelAttribute StudentModel student) {
        studentService.addStudent(student);
        return "redirect:/students";
    }

    @PostMapping("/update")
    public String updateStudent(@ModelAttribute StudentModel student) {
        studentService.updateStudent(student);
        return "redirect:/students";
    }

    @PostMapping("/delete/{id}")
    public String deleteOne(@PathVariable int id, @RequestParam(defaultValue = "logical") String mode) {
        if ("physical".equalsIgnoreCase(mode)) studentService.deleteStudentPhysical(id);
        else studentService.deleteStudentLogical(id);
        return "redirect:/students";
    }

    @PostMapping("/delete-multiple")
    public String deleteMultiple(@RequestParam String ids, @RequestParam(defaultValue = "logical") String mode) {
        List<Integer> list = Arrays.stream(ids.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(Integer::parseInt)
                .collect(Collectors.toList());
        if ("physical".equalsIgnoreCase(mode)) studentService.deleteMultiplePhysical(list);
        else studentService.deleteMultipleLogical(list);
        return "redirect:/students";
    }
}
