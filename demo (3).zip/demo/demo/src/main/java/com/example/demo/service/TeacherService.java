package com.example.demo.service;

import com.example.demo.model.TeacherModel;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TeacherService {

    private final List<TeacherModel> teachers = new ArrayList<>();
    private int nextId = 1;

    public TeacherService() {
        // Добавим 11 дефолтных преподавателей на русском
        addTeacher(new TeacherModel(0, "Иван", "Иванов", "Математика", LocalDate.of(2010, 1, 15)));
        addTeacher(new TeacherModel(0, "Алиса", "Петрова", "Физика", LocalDate.of(2012, 3, 20)));
        addTeacher(new TeacherModel(0, "Роберт", "Сидоров", "Химия", LocalDate.of(2011, 5, 5)));
        addTeacher(new TeacherModel(0, "Екатерина", "Давыдова", "Биология", LocalDate.of(2015, 7, 10)));
        addTeacher(new TeacherModel(0, "Михаил", "Михайлов", "История", LocalDate.of(2009, 9, 1)));
        addTeacher(new TeacherModel(0, "Юлия", "Васильева", "Английский язык", LocalDate.of(2013, 11, 30)));
        addTeacher(new TeacherModel(0, "Даниил", "Моисеев", "География", LocalDate.of(2014, 2, 12)));
        addTeacher(new TeacherModel(0, "Светлана", "Тарасова", "Информатика", LocalDate.of(2016, 6, 18)));
        addTeacher(new TeacherModel(0, "Денис", "Андреев", "ИЗО", LocalDate.of(2010, 8, 25)));
        addTeacher(new TeacherModel(0, "Людмила", "Тихонова", "Музыка", LocalDate.of(2012, 10, 8)));
        addTeacher(new TeacherModel(0, "Алексей", "Жуков", "Физкультура", LocalDate.of(2008, 12, 3)));
    }


    public List<TeacherModel> findAll() {
        return teachers.stream().filter(t -> !t.isDeleted()).collect(Collectors.toList());
    }

    public void addTeacher(TeacherModel t) {
        t.setId(nextId++);
        teachers.add(t);
    }

    public List<TeacherModel> search(String text) {
        return teachers.stream()
                .filter(t -> !t.isDeleted() && (
                        t.getFirstName().toLowerCase().contains(text.toLowerCase()) ||
                                t.getLastName().toLowerCase().contains(text.toLowerCase()) ||
                                t.getSubject().toLowerCase().contains(text.toLowerCase())
                ))
                .collect(Collectors.toList());
    }

    public List<TeacherModel> filter(String subject, LocalDate from, LocalDate to) {
        return teachers.stream()
                .filter(t -> !t.isDeleted())
                .filter(t -> subject == null || subject.isBlank() || t.getSubject().equalsIgnoreCase(subject))
                .filter(t -> from == null || !t.getHireDate().isBefore(from))
                .filter(t -> to == null || !t.getHireDate().isAfter(to))
                .collect(Collectors.toList());
    }

    public List<TeacherModel> page(int page, int size) {
        return findAll().stream()
                .skip((long) page * size)
                .limit(size)
                .collect(Collectors.toList());
    }

    public void deleteTeacherLogical(int id) {
        teachers.stream().filter(t -> t.getId() == id).findFirst().ifPresent(t -> t.setDeleted(true));
    }

    public void deleteTeacherPhysical(int id) {
        teachers.removeIf(t -> t.getId() == id);
    }

    public int countAll() {
        return (int) teachers.stream().filter(t -> !t.isDeleted()).count();
    }
}
