package com.example.demo.repository;

import com.example.demo.entity.StudentEntity;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Repository
public class InMemoryStudentRepository {
    private final List<StudentEntity> students = new ArrayList<>();
    private final AtomicInteger idCounter = new AtomicInteger(1);

    public InMemoryStudentRepository() {
        save(new StudentEntity(0, "Иван", "Иванов", "A1", LocalDate.of(2000,1,1)));
        save(new StudentEntity(0, "Пётр", "Петров", "B2", LocalDate.of(1999,5,10)));
        save(new StudentEntity(0, "Анна", "Сидорова", "A1", LocalDate.of(2001,3,14)));
        save(new StudentEntity(0, "Ольга", "Кузнецова", "B2", LocalDate.of(2002,7,22)));
        save(new StudentEntity(0, "Сергей", "Смирнов", "A1", LocalDate.of(2000,11,30)));
        save(new StudentEntity(0, "Мария", "Федорова", "C3", LocalDate.of(1998,4,12)));
        save(new StudentEntity(0, "Андрей", "Ковалёв", "A2", LocalDate.of(2001,6,8)));
        save(new StudentEntity(0, "Дмитрий", "Егоров", "C1", LocalDate.of(1999,9,15)));
        save(new StudentEntity(0, "Наталья", "Попова", "B1", LocalDate.of(2002,2,19)));
        save(new StudentEntity(0, "Кирилл", "Михайлов", "A3", LocalDate.of(2000,8,25)));
        save(new StudentEntity(0, "Елена", "Васильева", "C2", LocalDate.of(2001,10,5)));
    }



    public StudentEntity save(StudentEntity s) {
        if (s.getId() == 0) {
            s.setId(idCounter.getAndIncrement());
            students.add(s);
        } else {
            // если студент уже есть — обновляем
            for (int i = 0; i < students.size(); i++) {
                if (students.get(i).getId() == s.getId()) {
                    students.set(i, s);
                    return s;
                }
            }
            // если не нашли — добавляем
            students.add(s);
        }
        return s;
    }


    public void deleteByIdPhysical(int id) {
        students.removeIf(st -> st.getId() == id);
    }

    public void deleteByIdLogical(int id) {
        students.stream().filter(st -> st.getId() == id).findFirst().ifPresent(st -> st.setDeleted(true));
    }

    public void deleteMultiplePhysical(List<Integer> ids) {
        students.removeIf(st -> ids.contains(st.getId()));
    }

    public void deleteMultipleLogical(List<Integer> ids) {
        students.stream().filter(st -> ids.contains(st.getId())).forEach(st -> st.setDeleted(true));
    }

    public StudentEntity findById(int id) {
        return students.stream().filter(st -> st.getId() == id).findFirst().orElse(null);
    }

    public List<StudentEntity> searchBy(String term) {
        if (term == null || term.isBlank()) return findAll(false);
        String t = term.trim().toLowerCase();
        return students.stream()
                .filter(st -> !st.isDeleted())
                .filter(st -> (st.getFirstName()!=null && st.getFirstName().toLowerCase().contains(t))
                        || (st.getLastName()!=null && st.getLastName().toLowerCase().contains(t))
                        || (st.getGroupName()!=null && st.getGroupName().toLowerCase().contains(t)))
                .collect(Collectors.toList());
    }

    public List<StudentEntity> filter(String group, LocalDate from, LocalDate to) {
        Predicate<StudentEntity> p = st -> !st.isDeleted();
        if (group != null && !group.isBlank()) {
            String g = group.trim().toLowerCase();
            p = p.and(st -> st.getGroupName() != null && st.getGroupName().toLowerCase().equals(g));
        }
        if (from != null) p = p.and(st -> st.getBirthDate() != null && !st.getBirthDate().isBefore(from));
        if (to != null) p = p.and(st -> st.getBirthDate() != null && !st.getBirthDate().isAfter(to));
        return students.stream().filter(p).collect(Collectors.toList());
    }

    public List<StudentEntity> findAll(boolean includeDeleted) {
        if (includeDeleted) return new ArrayList<>(students);
        return students.stream().filter(st -> !st.isDeleted()).collect(Collectors.toList());
    }


    public List<StudentEntity> findPage(int pageIndex, int pageSize) {
        int size = Math.max(pageSize, 10);
        int from = pageIndex * size;
        List<StudentEntity> visible = findAll(false);
        if (from >= visible.size()) return new ArrayList<>();
        int to = Math.min(from + size, visible.size());
        return visible.subList(from, to);
    }
}