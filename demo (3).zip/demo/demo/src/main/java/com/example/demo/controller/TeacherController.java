package com.example.demo.controller;

import com.example.demo.model.TeacherModel;
import com.example.demo.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/teachers")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    @GetMapping({"", "/"})
    public String list(
            Model model,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String subject,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        size = Math.max(size, 10);
        List<TeacherModel> list;
        if (search != null && !search.isBlank()) {
            list = teacherService.search(search);
        } else if ((subject != null && !subject.isBlank()) || from != null || to != null) {
            list = teacherService.filter(subject, from, to);
        } else {
            list = teacherService.page(page, size);
        }
        int totalPages = (int) Math.ceil((double) teacherService.countAll() / size);

        model.addAttribute("teachers", list);
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("search", search);
        model.addAttribute("subject", subject);
        model.addAttribute("from", from);
        model.addAttribute("to", to);
        model.addAttribute("totalPages", totalPages);
        return "teacherList";
    }

    @PostMapping("/add")
    public String addTeacher(@ModelAttribute TeacherModel teacher) {
        teacherService.addTeacher(teacher);
        return "redirect:/teachers";
    }

    @PostMapping("/update")
    public String updateTeacher(@ModelAttribute TeacherModel teacher) {
        // Находим существующего учителя по id
        List<TeacherModel> all = teacherService.findAll();
        for (TeacherModel t : all) {
            if (t.getId() == teacher.getId()) {
                t.setFirstName(teacher.getFirstName());
                t.setLastName(teacher.getLastName());
                t.setSubject(teacher.getSubject());
                t.setHireDate(teacher.getHireDate());
                break;
            }
        }
        return "redirect:/teachers";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable int id, @RequestParam(defaultValue = "logical") String mode) {
        if ("physical".equalsIgnoreCase(mode)) teacherService.deleteTeacherPhysical(id);
        else teacherService.deleteTeacherLogical(id);
        return "redirect:/teachers";
    }
}
